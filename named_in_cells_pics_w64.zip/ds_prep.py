import collections

smiles = [smile for c,smile in id_to_zinc_smile_20.values()]
smiles_padded = [smile + ' ' * (25-len(smile)) for smile in smiles]

smiles_all = ''.join(smiles_padded)

def build_dataset(words):
    count = collections.Counter(words).most_common()
    dictionary = {}
    for word, _ in count:
        dictionary[word] = len(dictionary)
    reverse_dictionary = dict(zip(dictionary.values(), dictionary.keys()))
    return dictionary, reverse_dictionary

dictionary, reverse_dictionary = build_dataset(smiles_all)

smiles_as_int = np.array( [[dictionary[c] for c in smile] for smile in smiles_padded])
print(smiles_as_int[2])